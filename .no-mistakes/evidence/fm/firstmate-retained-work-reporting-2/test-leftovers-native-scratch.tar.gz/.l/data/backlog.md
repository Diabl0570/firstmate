## In flight
- [ ] predecessor - Retained failed attempt (repo: sample) (kind: ship) (hold: source retention) (hold-kind: external)
- [ ] delivered - Delivered attempt awaiting approval (repo: sample) (kind: ship) (hold: review delivery) (hold-kind: captain)
- [ ] continuation - Current continuation (repo: sample) (kind: ship)

## Queued

## Done
